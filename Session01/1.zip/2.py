# age=2018-int(input("năm sinh"))
# if age <= 14: print("baby")
# elif age<18: print("teenager")
# else: print ("adult")
#
# import math
# phuong trinh bac 2 hahaha
# a=int(input("nhap so a"))
# if a==0:
#     print("ko phai phg trinh b2")
# else:
#     b=int(input("nhap so b"))
#     c=int(input("nhap so c"))
#     delta=b**2-4*a*c
#     if delta >=0:
#         x1=(-b+math.sqrt(delta))/(2*a)
#         x2=(-b-math.sqrt(delta))/(2*a)
#         if x1==x2:print("pt co nghiem kep",x1)
#         else:
#             print(x1)
#             print(x2)
#     else:
#         print("vo no")

a=[] #khai bao MẢNG!!!!
b=[1,4,5] #khai bao va khoi tao bang

# for i in range (100):
#     a.append(i)
# #cách 1
# for i in b:
#     #print(i, end =" ") #end blabla để ko bị xuống dòng
# #cách 2
# #print(end='\n')
# for i in range(len(b)):
#     #print(b[i],end =" ")

#mảng chứa được nhiều loại dữ liệu khác nhau
# c=["tuan",1,{1,4}]
# for i in c:
#     print(i, end=" ")

#tạo mảng 5 ptu, tổng mảng, max of mảng
d=[4,5,25,20,9]

# sum=0
# for i in d:
#     sum=sum+i
# print("sum: ",sum)
#
# max_value= -99999
# for i in d:
#     if i>max_value:
#         max_value=i
# print("max_value: ",max_value)

# from sub_function import*
#
# b=[1,2,5]
# c=[3,6,7,8,9]
# tongb=tinhtong_mang(b)
# tongc=tinhtong_mang(c)
# print(tongb)
# print(tongc)

#cách 1: import sub_function khuyến khích
#from sub_function import*
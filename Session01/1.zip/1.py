print("yo wassup") #comment la cong cu quan li codeee
# yob=input("years of birth")
# age=2018-yob
# print("age:",age)

from turtle import * #import tất cả các hàm

shape ("turtle")

speed(0)
color("magenta")
for i in range(360):
    forward(2)
    left(1)

# circle(100)

# forward(100)
# left(90)
# forward(100)
# left(90)
# forward(100)
# left(30)
# forward(100)
# left(90)
# forward(100)
# left(90)
# forward(100)
# left(90)
# forward(100)
n=input("")